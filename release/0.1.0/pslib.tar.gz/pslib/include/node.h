#pragma once
#include <thread>
#include <memory>
#include <iostream>
#include "proto/ps.pb.h"

//todo-need to remove mpi_wrapper lib 
namespace mpi_wrapper {
    class MPIWrapper;
    class ModelParam;
    class WorkerNode;
}

namespace paddle {
    namespace ps {
        /**
         * GeoPsClient implements data parallel
         * training mechanism for normal deep neural network training
         **/
        class GeoPsClient{
        public:
            explicit GeoPsClient();
            virtual ~GeoPsClient();
            virtual int start(int thread_num);
            virtual void stop();
            virtual void start_inner_working_threads();
            virtual void join_inner_working_threads();
            virtual bool wait_for_push();
            virtual void ready_to_push(int epoch);
            virtual void register_dense_table(float * param, int row, int col);
            virtual void register_sparse_table(float * param, int vocab, int dim);
            virtual void add_sparse_keys(int table_index, int thread_id, int num, int* keys);
            virtual void prepare_push_value();
            //virtual void add_fidset();
        private:
            mpi_wrapper::MPIWrapper * _mpi_wrapper;
            mpi_wrapper::WorkerNode * _mpi_worker;
            mpi_wrapper::ModelParam * _table;
            std::vector<std::thread> _worker_threads;
        };

        /**
         * GeoServer inherits from Server. GeoServer implements data parallel
         * training mechanism for normal deep neural network training
         **/
        class GeoPsServer {
        public:
            explicit GeoPsServer();
            virtual ~GeoPsServer();
            virtual int start();
            virtual void stop();
            virtual void register_dense_table(float * param, int row, int col);
            virtual void register_sparse_table(float * param, int vocab, int dim);
        private:
            mpi_wrapper::MPIWrapper * _mpi_wrapper;
            mpi_wrapper::ModelParam * _table;
        };
    }
}
